var input = document.querySelector("#phone");
window.intlTelInput(input, {
  hiddenInput: "full_phone",
  utilsScript: "../../build/js/utils.js?1560794689211" // just for formatting/placeholders etc
});
